#' ising: compute maximum likelihood estimators in graphical Ising models
#'
#' The ising package provides functions for maximum likelihood estimation,
#' sampling, computing likelihoods, and performing likelihood ratio tests with
#' bootstrapping in graphical Ising models with MTP_2 constraints.
#'
#'
#' @section ising functions:
#' \strong{isingMLE}: Find the maximum likelihood estimate in a graphical
#' Ising model.\cr
#' \strong{IsingMLEmtp2}: Find the maximum likelihood estimate in a graphical
#' Ising model with MTP_2 constraints. \cr
#' \strong{IsingSampler}: Sample from a graphical Ising model. \cr
#' \strong{IsingLikelihood}: Compute the likelihood of a data set from a
#' graphical Ising model. \cr
#' \strong{BootstrapLikelihoodRatio}: Simulate from the null-distribution to
#' estimate the distribution of the likelihood ratio test statistic. \cr
#'
#'
#' @docType package
#' @name ising
NULL
